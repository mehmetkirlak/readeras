package com.narval.readeras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReaderasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReaderasApplication.class, args);
	}

}
